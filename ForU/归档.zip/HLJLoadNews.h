//
//  HLJLoadNews.h
//  ForU
//
//  Created by 胡礼节 on 15/10/19.
//  Copyright © 2015年 胡礼节. All rights reserved.
//

#import "HLJLoadNewsVIew.h"

@interface HLJLoadNews : HLJLoadNewsVIew

@end
